from itertools import *

count = 0 # нумерация слов с 1
for i in product(sorted('ВЕСНА'), repeat=4):
    count += 1
    word = ''.join(i)
    # ...