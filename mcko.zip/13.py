with open('13.txt') as f:
    data = f.readlines()
    data = [int(x) for x in data]

#...