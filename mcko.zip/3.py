def to_dec(x, osn):
    x = str(x).replace(',', '.').upper()
    digs = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    if '.' in x:
        a, b = x.split('.')
    else:
        a, b = x, ''
    res = 0
    for i, c in enumerate(a[::-1]):
        res += digs.index(c) * osn ** i
    for i, c in enumerate(b, 1):
        res += digs.index(c) * osn ** (-i)
    return res


def from_dec(x, osn, prec=10):
    digs = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    a = int(x)
    b = x - a
    res = ''
    if a == 0:
        res = '0'
    else:
        while a:
            a, r = divmod(a, osn)
            res = digs[r] + res
    if b > 0:
        frac = ''
        for _ in range(prec):
            b *= osn
            d = int(b)
            frac += digs[d]
            b -= d
        frac = frac.rstrip('0')
        if frac:
            res += ',' + frac
    if ',' not in res:
        return int(res)
    return res


x = 16 #Чему равно значение выражения в системе счисления с основанием ...?
s = to_dec('1011,01', 2) + to_dec('24,6', 8)
print(from_dec(s, x))
