from __future__ import annotations

import itertools
import os
import re
import sys
from collections import Counter
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Callable, Dict, Iterable, List, Optional, Sequence, Set, Tuple

BITS = "01"
LETTERS_RE = "А-ЯЁA-Z"
LETTER_LIST_RE = rf"\b[{LETTERS_RE}]\b(?:\s*(?:,|\s+и\s+)\s*\b[{LETTERS_RE}]\b)+"
WORD_NUMBER = {
    "одна": 1, "одну": 1, "один": 1,
    "две": 2, "два": 2, "двух": 2,
    "три": 3, "трех": 3, "трёх": 3,
    "четыре": 4, "четырех": 4, "четырёх": 4,
    "пять": 5, "пяти": 5,
    "шесть": 6, "шести": 6,
    "семь": 7, "семи": 7,
    "восемь": 8, "восьми": 8,
    "девять": 9, "девяти": 9,
    "десять": 10, "десяти": 10,
    "одиннадцать": 11, "одиннадцати": 11,
    "двенадцать": 12, "двенадцати": 12,
}


# ============================================================
# Normalization helpers
# ============================================================

def normalize_text(text: str) -> str:
    replacements = {
        "\xa0": " ",
        "\u00ad": "",     # soft hyphen inside words from web pages
        "\u2011": "-",
        "\u2012": "-",
        "\u2013": "-",
        "\u2014": "-",
        "—": "-",
        "–": "-",
        "−": "-",
        "⁠": "",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"[ \t]+", " ", text)
    return text.strip()


def clean_name(name: str) -> str:
    name = normalize_text(name).strip(" .,:;()[]{}\n\t")
    if len(name) == 1:
        return name.upper().replace("Е", "Е")
    return name[:1].upper() + name[1:].lower()


def extract_single_symbols(fragment: str) -> List[str]:
    """Extract one-letter symbols from Russian task fragments.

    The task wording often says: А, Б, В и Г.  This helper intentionally
    ignores multi-letter words, so it does not accidentally treat words from
    the statement as alphabet symbols.
    """
    return [x.upper() for x in re.findall(rf"\b[{LETTERS_RE}]\b", fragment, re.I)]


def extract_binary_codes(fragment: str) -> List[str]:
    return re.findall(r"\b[01]+\b", fragment)


def split_condition(text: str) -> str:
    """Keep only the statement, not notes/solutions/answers."""
    cut_words = ["Примечание", "Решение", "Ответ:", "Показать решение"]
    indexes = [text.find(w) for w in cut_words if text.find(w) != -1]
    return text[:min(indexes)].strip() if indexes else text.strip()


def extract_number_near(text: str, nouns: Sequence[str]) -> Optional[int]:
    noun_pat = "|".join(map(re.escape, nouns))
    m = re.search(rf"(\d+)\s+(?:{noun_pat})", text, re.I)
    if m:
        return int(m.group(1))
    m = re.search(rf"({'|'.join(WORD_NUMBER)})\s+(?:{noun_pat})", text, re.I)
    if m:
        return WORD_NUMBER[m.group(1).lower().replace("ё", "е")]
    return None


# ============================================================
# Prefix-code engine
# ============================================================

def is_prefix_free(codes: Iterable[str]) -> bool:
    codes = list(codes)
    if len(codes) != len(set(codes)):
        return False
    for a in codes:
        for b in codes:
            if a != b and b.startswith(a):
                return False
    return True


def can_add(used: frozenset[str], code: str) -> bool:
    if not code or code in used:
        return False
    for i in range(1, len(code)):
        if code[:i] in used:
            return False
    for old in used:
        if old.startswith(code):
            return False
    return True


def add_code(used: frozenset[str], code: str) -> frozenset[str]:
    return frozenset(set(used) | {code})


def has_descendant(used: frozenset[str], prefix: str) -> bool:
    return any(code.startswith(prefix) for code in used)


@lru_cache(maxsize=None)
def free_frontiers(used: frozenset[str]) -> Tuple[str, ...]:
    """Roots of subtrees where no used code exists and no used ancestor blocks them."""
    if not used:
        return ("",)
    ans: List[str] = []

    def walk(prefix: str) -> None:
        if prefix in used:
            return
        if has_descendant(used, prefix):
            walk(prefix + "0")
            walk(prefix + "1")
        else:
            ans.append(prefix)

    walk("")
    return tuple(ans)


@lru_cache(maxsize=None)
def capacity(used: frozenset[str], max_len: int) -> int:
    total = 0
    for prefix in free_frontiers(used):
        if len(prefix) <= max_len:
            total += 1 << (max_len - len(prefix))
    return total


@lru_cache(maxsize=None)
def generated_transformed_candidates(used: frozenset[str], max_len: int) -> Tuple[str, ...]:
    result: List[str] = []
    for prefix in free_frontiers(used):
        start_len = max(1, len(prefix))
        for total_len in range(start_len, max_len + 1):
            suffix_len = total_len - len(prefix)
            for suffix in itertools.product(BITS, repeat=suffix_len):
                result.append(prefix + "".join(suffix))
    # The generation through frontiers already gives valid codes, but keep it safe.
    result = [code for code in result if can_add(used, code)]
    result.sort(key=lambda c: (len(c), c))
    return tuple(result)


@dataclass
class ExactCodeSolver:
    known_codes: Dict[str, str]
    reserved_codes: List[str] = field(default_factory=list)
    reverse_fano: bool = False
    max_len: Optional[int] = None

    def transform(self, code: str) -> str:
        return code[::-1] if self.reverse_fano else code

    def initial_used(self) -> frozenset[str]:
        used: frozenset[str] = frozenset()
        for code in list(self.known_codes.values()) + list(self.reserved_codes):
            tcode = self.transform(code)
            if not can_add(used, tcode):
                raise ValueError("Known code words do not satisfy the selected Fano condition")
            used = add_code(used, tcode)
        return used

    def default_max_len(self, unknown_count: int) -> int:
        longest = max([len(c) for c in list(self.known_codes.values()) + list(self.reserved_codes)] + [1])
        return max(8, longest + unknown_count + 1)

    def candidates(self, used: frozenset[str], max_len: int, prefer_largest_numeric: bool = False) -> List[str]:
        transformed = generated_transformed_candidates(used, max_len)
        actual = [self.transform(code) for code in transformed]
        # Equal length numeric order is the same as lexicographic order for binary strings.
        actual.sort(key=lambda c: (len(c), c), reverse=False)
        if prefer_largest_numeric:
            by_len: Dict[int, List[str]] = {}
            for code in actual:
                by_len.setdefault(len(code), []).append(code)
            actual = []
            for length in sorted(by_len):
                actual.extend(sorted(by_len[length], reverse=True))
        return actual

    def shortest_code(
        self,
        target: str,
        other_unknowns: Sequence[str],
        prefer_largest_numeric: bool = False,
    ) -> Optional[str]:
        unknown_count = 1 + len(other_unknowns)
        max_len = self.max_len or self.default_max_len(unknown_count)
        used = self.initial_used()
        for code in self.candidates(used, max_len, prefer_largest_numeric):
            tcode = self.transform(code)
            if not can_add(used, tcode):
                continue
            new_used = add_code(used, tcode)
            if capacity(new_used, max_len) >= len(other_unknowns):
                return code
        return None

    def minimize(
        self,
        unknown_symbols: Sequence[str],
        weight: Dict[str, int],
        code_cost: Callable[[str], int],
    ) -> Optional[Tuple[int, Dict[str, str]]]:
        """Minimize sum(weight[symbol] * code_cost(code)). Zero-weight symbols only need to be encodable."""
        symbols = list(unknown_symbols)
        max_len = self.max_len or self.default_max_len(len(symbols))
        used0 = self.initial_used()
        if capacity(used0, max_len) < len(symbols):
            return None

        # Put important symbols first; this massively cuts branching.
        symbols.sort(key=lambda s: (-weight.get(s, 0), s))
        best_cost = float("inf")
        best_assign: Dict[str, str] = {}
        assignment: Dict[str, str] = {}

        @lru_cache(maxsize=None)
        def suffix_positive_weight(start: int) -> int:
            return sum(max(0, weight.get(s, 0)) for s in symbols[start:])

        def dfs(index: int, used: frozenset[str], current_cost: int) -> None:
            nonlocal best_cost, best_assign
            if current_cost >= best_cost:
                return
            if index == len(symbols):
                best_cost = current_cost
                best_assign = dict(assignment)
                return

            remaining_symbols = symbols[index:]
            if all(weight.get(s, 0) == 0 for s in remaining_symbols):
                if capacity(used, max_len) >= len(remaining_symbols):
                    best_cost = current_cost
                    best_assign = dict(assignment)
                return

            sym = symbols[index]
            rest_count = len(symbols) - index - 1
            cands = self.candidates(used, max_len)
            cands.sort(key=lambda c: (weight.get(sym, 0) * code_cost(c), len(c), c))
            for code in cands:
                inc = weight.get(sym, 0) * code_cost(code)
                if current_cost + inc >= best_cost:
                    continue
                tcode = self.transform(code)
                if not can_add(used, tcode):
                    continue
                new_used = add_code(used, tcode)
                if capacity(new_used, max_len) < rest_count:
                    continue
                assignment[sym] = code
                dfs(index + 1, new_used, current_cost + inc)
                assignment.pop(sym, None)

        dfs(0, used0, 0)
        if best_cost == float("inf"):
            return None
        return int(best_cost), best_assign


# ============================================================
# Parser
# ============================================================

@dataclass
class ParsedTask:
    text: str
    condition: str
    symbols: List[str]
    known_codes: Dict[str, str]
    reserved_codes: List[str]
    target_word: str
    target_symbols: List[str]
    qtype: str
    reverse_fano: bool
    prefer_largest_numeric: bool

    def debug(self) -> str:
        return (
            f"symbols={self.symbols}, known={self.known_codes}, reserved={self.reserved_codes}, "
            f"word={self.target_word}, target={self.target_symbols}, type={self.qtype}, "
            f"reverse={self.reverse_fano}, largest={self.prefer_largest_numeric}"
        )


class TaskParser:
    def __init__(self, text: str):
        self.text = normalize_text(text)
        self.condition = split_condition(self.text)
        self.known_codes: Dict[str, str] = {}
        self.reserved_codes: List[str] = []
        self.symbols: List[str] = []

    def parse(self) -> ParsedTask:
        self.symbols = self.extract_alphabet()
        self.known_codes = self.extract_known_codes()
        self.reserved_codes = self.extract_reserved_codes()
        self.symbols = self.complete_alphabet(self.symbols, self.known_codes, self.reserved_codes)
        target_word = self.extract_target_word()
        target_symbols = self.extract_target_symbols()
        qtype = self.detect_qtype(target_word)
        reverse_fano = self.detect_reverse_fano()
        prefer_largest = self.detect_largest_numeric()
        return ParsedTask(
            text=self.text,
            condition=self.condition,
            symbols=self.symbols,
            known_codes=self.known_codes,
            reserved_codes=self.reserved_codes,
            target_word=target_word,
            target_symbols=target_symbols,
            qtype=qtype,
            reverse_fano=reverse_fano,
            prefer_largest_numeric=prefer_largest,
        )

    def extract_alphabet(self) -> List[str]:
        text = self.condition
        # Letter lists: "буквы А, Б, В" / "букв: А, Б, В" / "букв А, Б и В".
        patterns = [
            rf"(?:состоящ\w*\s+из\s+букв|содержащ\w*\s+только\s+(?:\d+|[а-яё]+)?\s*букв|только\s+(?:\d+|[а-яё]+)?\s*букв|буквы)\s*[:\-]?\s*({LETTER_LIST_RE})",
            rf"букв\s*[:\-]\s*({LETTER_LIST_RE})",
        ]
        for pat in patterns:
            m = re.search(pat, text, re.I)
            if m:
                letters = extract_single_symbols(m.group(1))
                if len(letters) >= 2:
                    return unique(letters)

        # Colors/paints. First use names that appear in table-like pairs.
        color_count = extract_number_near(text, ["красок", "краски", "цветов", "цвета"])
        color_names = self.extract_color_names_from_table(text)
        if color_count:
            symbols = color_names[:]
            target = self.extract_color_target(text)
            if target and target not in symbols:
                symbols.append(target)
            while len(symbols) < color_count:
                symbols.append(f"Ц{len(symbols) + 1}")
            return symbols[:color_count]

        # If only the number of letters is given, create placeholders.
        letter_count = extract_number_near(text, ["букв", "буквы"])
        if letter_count and not re.search(rf"[{LETTERS_RE}]\s*,\s*[{LETTERS_RE}]", text):
            return [f"Б{i + 1}" for i in range(letter_count)]
        return []

    def extract_color_names_from_table(self, text: str) -> List[str]:
        names: List[str] = []
        stop = {"Для", "Цвет", "Кодовое", "Слово", "Укажите", "Если", "При", "Код"}
        for m in re.finditer(r"\b([А-ЯЁ][а-яё]+)\s+([01]{1,12})\b", text):
            name = clean_name(m.group(1))
            if name not in stop and name not in names:
                names.append(name)
        # Also catch a target color name in a row without code, e.g. "Белый 1000 Зелёный".
        target = self.extract_color_target(text)
        if target and target not in names:
            names.append(target)
        return names

    def extract_color_target(self, text: str) -> Optional[str]:
        m = re.search(r"для\s+кодирования\s+([А-ЯЁа-яё]+)\s+цвет", text, re.I)
        if m:
            return color_to_nominative(m.group(1))
        m = re.search(r"для\s+([А-ЯЁа-яё]+)\s+цвет", text, re.I)
        if m:
            return color_to_nominative(m.group(1))
        return None

    def extract_corresponding_letter_codes(self, text: str) -> Dict[str, str]:
        """Parse statements with correspondence by order.

        Examples:
        - Для букв А, Б, В, Г использовали соответственно кодовые слова 000, 001, 10, 11.
        - Для букв А, Б, В и Г используются кодовые слова 00, 01, 10 и 11 соответственно.
        - Для букв Т, О, П используются такие кодовые слова: Т — 111, О — 0, П — 100.
        """
        found: Dict[str, str] = {}

        # Letter-code pairs inside a "for letters ... such code words ..." sentence.
        # This catches compact forms like: Т — 111, О — 0, П — 100.
        for sent in re.split(r"[.?!]", text):
            low = sent.lower().replace("ё", "е")
            if "букв" not in low or "кодов" not in low:
                continue

            explicit_pairs = re.findall(rf"\b([{LETTERS_RE}])\s*[-:]\s*([01]+)\b", sent, re.I)
            if explicit_pairs:
                for sym, code in explicit_pairs:
                    sym = sym.upper()
                    if self.symbols and sym not in self.symbols:
                        continue
                    found[sym] = code

            if "соответствен" not in low:
                continue

            # The letters are between "для букв" and the first verb / "кодовые слова".
            m_letters = re.search(
                rf"для\s+букв[ыа]?\s+(.+?)(?:\s+(?:использ|были|примен|задал|кодовые\s+слова)|$)",
                sent,
                re.I,
            )
            if not m_letters:
                continue
            letters = extract_single_symbols(m_letters.group(1))

            # The codes are normally after "кодовые слова", optionally before/after
            # the word "соответственно".
            m_codes = re.search(r"кодовые\s+слова\s*:?\s*(.+)$", sent, re.I)
            if not m_codes:
                continue
            codes_part = re.sub(r"\bсоответственно\b", " ", m_codes.group(1), flags=re.I)
            bin_codes = extract_binary_codes(codes_part)

            if len(letters) == len(bin_codes) and letters:
                for sym, code in zip(letters, bin_codes):
                    if self.symbols and sym not in self.symbols:
                        continue
                    found[sym] = code

        return found

    def extract_known_codes(self) -> Dict[str, str]:
        text = self.condition
        codes: Dict[str, str] = {}

        # Order-correspondence forms must go first.  Otherwise a regex can see
        # only a single letter and lose the mapping.
        codes.update(self.extract_corresponding_letter_codes(text))

        # "Для буквы Н использовали кодовое слово 0" / "для буквы К кодовое слово 01".
        for m in re.finditer(
            rf"для\s+букв[ыа]?\s+([{LETTERS_RE}])\s*(?:использ\w+\s*)?(?:-|:)?\s*(?:кодовое\s+слово\s*)?([01]+)",
            text,
            re.I,
        ):
            codes[m.group(1).upper()] = m.group(2)

        # "К использовали кодовое слово 01".
        for m in re.finditer(rf"\b([{LETTERS_RE}])\s+(?:использ\w+|имеет)\s+(?:кодовое\s+слово|код)\s+([01]+)", text, re.I):
            codes[m.group(1).upper()] = m.group(2)

        # Pairs with dash/colon: "А — 010", "К: 10", "Белый 1000".
        for m in re.finditer(rf"\b([{LETTERS_RE}])\s*[-:]\s*([01]+)\b", text, re.I):
            sym = m.group(1).upper()
            if self.symbols and sym not in self.symbols:
                continue
            codes[sym] = m.group(2)

        # Color/name pairs with dash or colon.
        for m in re.finditer(r"\b([А-ЯЁ][а-яё]+)\s*[-:]\s*([01]+)\b", text):
            name = clean_name(m.group(1))
            if name.lower() in {"слово", "код", "цвет"}:
                continue
            if self.symbols and name not in self.symbols:
                continue
            codes[name] = m.group(2)

        # Table-like color pairs: "Белый 1000   Красный 010".
        for m in re.finditer(r"\b([А-ЯЁ][а-яё]+)\s+([01]{1,12})\b", text):
            name = clean_name(m.group(1))
            if self.symbols and name in self.symbols:
                codes[name] = m.group(2)

        # Table format: symbol on one line, code on the next.
        for m in re.finditer(rf"\b([{LETTERS_RE}])\s*\n\s*([01]{{1,12}})\b", text, re.I):
            sym = m.group(1).upper()
            if self.symbols and sym not in self.symbols:
                continue
            codes.setdefault(sym, m.group(2))

        return codes

    def extract_reserved_codes(self) -> List[str]:
        text = self.condition
        reserved: List[str] = []
        patterns = [
            r"для\s+(?:двух|\d+)\s+букв\s+были\s+использованы\s+кодовые\s+слова\s+([^\.\?]+)",
            r"известно,?\s+что\s+для\s+(?:двух|\d+)\s+букв\s+были\s+использованы\s+кодовые\s+слова\s+([^\.\?]+)",
        ]
        for pat in patterns:
            for m in re.finditer(pat, text, re.I):
                for code in re.findall(r"\b[01]+\b", m.group(1)):
                    if code not in self.known_codes.values() and code not in reserved:
                        reserved.append(code)
        return reserved

    def complete_alphabet(self, symbols: List[str], known_codes: Dict[str, str], reserved_codes: List[str]) -> List[str]:
        result = unique(symbols + list(known_codes.keys()))
        count = extract_number_near(self.condition, ["букв", "буквы", "красок", "краски", "цветов", "цвета"])
        if count:
            while len(result) < count:
                result.append(f"?{len(result) + 1}")
        return result

    def extract_target_word(self) -> str:
        text = self.condition
        patterns = [
            rf"кодирования\s+(?:слова|последовательности)\s+([{LETTERS_RE}]{{2,}})",
            rf"для\s+последовательности\s+([{LETTERS_RE}]{{2,}})",
            rf"слова\s+([{LETTERS_RE}]{{2,}})\b",
        ]
        for pat in patterns:
            m = re.search(pat, text, re.I)
            if m:
                return m.group(1).upper()
        return ""

    def question_area(self) -> str:
        markers = ["Какова", "Какое", "Укажите", "Найдите", "Определите", "В ответе"]
        positions = [self.condition.find(x) for x in markers if self.condition.find(x) >= 0]
        return self.condition[min(positions):] if positions else self.condition

    def extract_target_symbols(self) -> List[str]:
        area = self.question_area()
        targets: List[str] = []

        color_target = self.extract_color_target(area)
        if color_target:
            targets.append(color_target)

        # "для букв В, Г, Д и Е"
        for m in re.finditer(rf"для\s+букв\s+({LETTER_LIST_RE})" , area, re.I):
            targets.extend(x.upper() for x in re.findall(rf"\b[{LETTERS_RE}]\b", m.group(1)))

        # "для буквы С"
        for m in re.finditer(rf"для\s+букв[ыа]?\s+([{LETTERS_RE}])\b", area, re.I):
            targets.append(m.group(1).upper())

        # "кодовое слово для О" (rare compact wording)
        for m in re.finditer(rf"кодовое\s+слово\s+для\s+([{LETTERS_RE}])\b", area, re.I):
            targets.append(m.group(1).upper())

        return unique(targets)

    def detect_qtype(self, target_word: str) -> str:
        low = self.condition.lower().replace("ё", "е")
        if "сумма цифр" in low or "сумму цифр" in low:
            return "MIN_DIGIT_SUM_WORD"
        if target_word and (
            "количество двоичных знаков" in low
            or "длину кодового слова для последовательности" in low
            or "длина кодового слова для последовательности" in low
            or "длины кодового слова для последовательности" in low
            or "кодирования слова" in low
        ):
            return "MIN_BITS_WORD"
        if "кратчайшее кодовое слово" in low or "кратчайший код" in low:
            return "SHORTEST_CODE"
        if re.search(r"кодовое\s+слово\s+для\s+букв", low) and not target_word:
            return "SHORTEST_CODE"
        if "суммарная длина всех" in low or "сумма длин всех" in low or "суммарную длину всех" in low:
            return "MIN_TOTAL_LEN"
        if ("сумму длин" in low or "сумма длин" in low or "суммарную длину" in low) and "для букв" in low:
            return "MIN_SUM_SUBSET"
        if target_word:
            return "MIN_BITS_WORD"
        if "суммарная длина" in low or "сумма длин" in low:
            return "MIN_TOTAL_LEN"
        return "UNKNOWN"

    def detect_reverse_fano(self) -> bool:
        low = self.condition.lower().replace("ё", "е")
        return "обратн" in low and "фано" in low

    def detect_largest_numeric(self) -> bool:
        low = self.condition.lower().replace("ё", "е")
        return "наибольшим числовым" in low or "наибольшее числовое" in low or "максимальным числовым" in low


def unique(seq: Iterable[str]) -> List[str]:
    seen: Set[str] = set()
    ans: List[str] = []
    for x in seq:
        if x and x not in seen:
            seen.add(x)
            ans.append(x)
    return ans


def color_to_nominative(word: str) -> str:
    w = clean_name(word)
    low = w.lower().replace("ё", "е")
    mapping = {
        "белого": "Белый", "белый": "Белый",
        "зеленого": "Зелёный", "зелёного": "Зелёный", "зеленый": "Зелёный", "зелёный": "Зелёный",
        "красного": "Красный", "красный": "Красный",
        "желтого": "Жёлтый", "жёлтого": "Жёлтый", "желтый": "Жёлтый", "жёлтый": "Жёлтый",
        "синего": "Синий", "синий": "Синий",
        "черного": "Чёрный", "чёрного": "Чёрный", "черный": "Чёрный", "чёрный": "Чёрный",
        "голубого": "Голубой", "голубой": "Голубой",
        "фиолетового": "Фиолетовый", "фиолетовый": "Фиолетовый",
        "оранжевого": "Оранжевый", "оранжевый": "Оранжевый",
        "серого": "Серый", "серый": "Серый",
    }
    return mapping.get(low, w)


# ============================================================
# Task solver
# ============================================================

class Solver:
    def __init__(self, parsed: ParsedTask):
        self.p = parsed

    def unknown_symbols(self) -> List[str]:
        # Reserved anonymous codes already correspond to some unknown alphabet symbols.
        unknown = [s for s in self.p.symbols if s not in self.p.known_codes]
        if self.p.reserved_codes:
            # Remove anonymous placeholders first; if no placeholders exist, remove from the end.
            for _ in self.p.reserved_codes:
                idx = next((i for i, s in enumerate(unknown) if s.startswith("?") or s.startswith("Б") or s.startswith("Ц")), None)
                if idx is None and unknown:
                    idx = len(unknown) - 1
                if idx is not None:
                    unknown.pop(idx)
        return unknown

    def exact(self) -> ExactCodeSolver:
        return ExactCodeSolver(
            known_codes=self.p.known_codes,
            reserved_codes=self.p.reserved_codes,
            reverse_fano=self.p.reverse_fano,
        )

    def solve(self) -> str:
        try:
            if self.p.qtype == "SHORTEST_CODE":
                return self.solve_shortest_code()
            if self.p.qtype == "MIN_BITS_WORD":
                return self.solve_word_length()
            if self.p.qtype == "MIN_DIGIT_SUM_WORD":
                return self.solve_word_digit_sum()
            if self.p.qtype == "MIN_TOTAL_LEN":
                return self.solve_total_length()
            if self.p.qtype == "MIN_SUM_SUBSET":
                return self.solve_subset_sum()
            return self.solve_fallback()
        except ValueError as exc:
            return f"ERROR: {exc}"

    def solve_shortest_code(self) -> str:
        target = self.choose_target()
        if not target:
            return "ERROR: не найден целевой символ"
        others = [s for s in self.unknown_symbols() if s != target]
        code = self.exact().shortest_code(target, others, self.p.prefer_largest_numeric)
        return code if code is not None else "ERROR"

    def solve_word_length(self) -> str:
        if not self.p.target_word:
            return "ERROR: не найдено слово"
        freq = Counter(self.p.target_word)
        fixed = 0
        weights: Dict[str, int] = {}
        for sym, count in freq.items():
            if sym in self.p.known_codes:
                fixed += count * len(self.p.known_codes[sym])
            else:
                weights[sym] = count
        unknown = self.unknown_symbols()
        for sym in freq:
            if sym not in self.p.known_codes and sym not in unknown:
                unknown.append(sym)
        result = self.exact().minimize(unknown, weights, len)
        if result is None:
            return "ERROR"
        best, _ = result
        return str(fixed + best)

    def solve_word_digit_sum(self) -> str:
        if not self.p.target_word:
            return "ERROR: не найдено слово"
        freq = Counter(self.p.target_word)
        fixed = 0
        weights: Dict[str, int] = {}
        for sym, count in freq.items():
            if sym in self.p.known_codes:
                fixed += count * self.p.known_codes[sym].count("1")
            else:
                weights[sym] = count
        unknown = self.unknown_symbols()
        for sym in freq:
            if sym not in self.p.known_codes and sym not in unknown:
                unknown.append(sym)
        result = self.exact().minimize(unknown, weights, lambda c: c.count("1"))
        if result is None:
            return "ERROR"
        best, _ = result
        return str(fixed + best)

    def solve_total_length(self) -> str:
        fixed = sum(len(code) for code in self.p.known_codes.values()) + sum(len(code) for code in self.p.reserved_codes)
        unknown = self.unknown_symbols()
        weights = {sym: 1 for sym in unknown}
        result = self.exact().minimize(unknown, weights, len)
        if result is None:
            return "ERROR"
        best, _ = result
        return str(fixed + best)

    def solve_subset_sum(self) -> str:
        targets = self.p.target_symbols[:]
        if not targets:
            targets = [s for s in self.unknown_symbols() if not s.startswith("?")]
        fixed = sum(len(self.p.known_codes[s]) for s in targets if s in self.p.known_codes)
        unknown = self.unknown_symbols()
        for sym in targets:
            if sym not in self.p.known_codes and sym not in unknown:
                unknown.append(sym)
        weights = {sym: (1 if sym in targets else 0) for sym in unknown}
        result = self.exact().minimize(unknown, weights, len)
        if result is None:
            return "ERROR"
        best, _ = result
        return str(fixed + best)

    def choose_target(self) -> Optional[str]:
        if self.p.target_symbols:
            return self.p.target_symbols[0]
        unknown = self.unknown_symbols()
        if len(unknown) == 1:
            return unknown[0]
        named = [s for s in unknown if not s.startswith("?") and not s.startswith("Ц") and not s.startswith("Б")]
        return named[0] if named else (unknown[0] if unknown else None)

    def solve_fallback(self) -> str:
        if self.p.target_word:
            return self.solve_word_length()
        if self.p.target_symbols:
            return self.solve_shortest_code() if len(self.p.target_symbols) == 1 else self.solve_subset_sum()
        return self.solve_total_length()


def solve(text: str, debug: bool = False) -> str:
    parsed = TaskParser(text).parse()
    if debug:
        return parsed.debug() + "\n" + Solver(parsed).solve()
    return Solver(parsed).solve()


def main() -> None:
    if len(sys.argv) > 1:
        with open(sys.argv[1], "r", encoding="utf-8") as f:
            text = f.read()
    else:
        filepath = "task.txt"
        if os.path.exists(filepath):
            with open(filepath, "r", encoding="utf-8") as f:
                text = f.read()
        else:
            print("ERROR: pass a file name or use 2.py with a task variable")
            sys.exit(1)
    print(solve(text))


if __name__ == "__main__":
    main()
