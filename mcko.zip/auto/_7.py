from __future__ import annotations

from dataclasses import dataclass
from ipaddress import IPv4Address, ip_address
from math import comb
import re


@dataclass
class Result:
    answer: str | int | list[int]
    task_type: str
    explanation: str = ""

    def __str__(self) -> str:
        if self.explanation:
            return f"Type: {self.task_type}\nAnswer: {self.answer}\n\n{self.explanation}"
        return f"Answer: {self.answer}"


# ------------------------- basic helpers -------------------------

IP_RE = r"(?:\d{1,3}\.){3}\d{1,3}"


def normalize_text(text: str) -> str:
    """Clean text copied from Reshu EGE/FIPI."""
    replacements = {
        "\u00ad": "",   # soft hyphen
        "⁠": "",        # word joiner
        "‑": "-",
        "–": "-",
        "—": "-",
        "−": "-",
        "ё": "е",
        "Ё": "Е",
        "\xa0": " ",
    }
    for old, new in replacements.items():
        text = text.replace(old, new)
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


def lower_normalized(text: str) -> str:
    return normalize_text(text).lower()


def ip_to_int(ip: str | IPv4Address | int) -> int:
    return int(ip_address(ip)) if not isinstance(ip, int) else ip


def int_to_ip(value: int) -> str:
    return str(ip_address(value))


def get_octets(ip: str | int | IPv4Address) -> list[int]:
    return [int(part) for part in str(ip_address(ip)).split(".")]


def mask_from_prefix(prefix: int) -> int:
    if prefix == 0:
        return 0
    return ((1 << 32) - 1) ^ ((1 << (32 - prefix)) - 1)


def prefix_from_mask(mask: str) -> int:
    bits = f"{ip_to_int(mask):032b}"
    if "01" in bits:
        raise ValueError(f"Invalid mask: {mask}")
    return bits.count("1")


def mask_octets(prefix: int) -> list[int]:
    return get_octets(mask_from_prefix(prefix))


def network_to_int(ip: str, prefix: int) -> int:
    return ip_to_int(ip) & mask_from_prefix(prefix)


def broadcast_to_int(ip: str, prefix: int) -> int:
    network = network_to_int(ip, prefix)
    return network | ((1 << (32 - prefix)) - 1)


def find_all_ips(text: str) -> list[str]:
    ips: list[str] = []
    for match in re.finditer(IP_RE, normalize_text(text)):
        ip = match.group(0)
        try:
            ip_address(ip)
            ips.append(ip)
        except ValueError:
            pass
    return ips


def find_mask(text: str) -> str | None:
    text = normalize_text(text)
    patterns = [
        rf"маск\w*\s*(?:сети|подсети|сетевая|сетевой)?\s*(?:равна|:)?\s*({IP_RE})",
        rf"сетев\w*\s+маск\w*\s*({IP_RE})",
        rf"/\s*({IP_RE})",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            ip = match.group(1)
            try:
                prefix_from_mask(ip)
                return ip
            except ValueError:
                pass

    # Fallback: choose an IP address that looks like a mask.
    for ip in find_all_ips(text):
        try:
            prefix_from_mask(ip)
            if ip.startswith("255") or ip == "0.0.0.0":
                return ip
        except ValueError:
            pass
    return None


def find_host_ip(text: str) -> str | None:
    text = normalize_text(text)
    patterns = [
        rf"ip[- ]?адрес(?:\s+одного\s+из\s+входящих\s+в\s+нее)?\s+узла\s*(?:равен|:)?\s*({IP_RE})",
        rf"ip[- ]?адрес\s+компьютера\s+в\s+сети\s*({IP_RE})",
        rf"ip[- ]?адрес\s+компьютера\s*(?:равен|:)?\s*({IP_RE})",
        rf"сеть\s+задана\s+ip[- ]?адресом(?:\s+одного\s+из\s+входящих\s+в\s+нее\s+узлов)?\s*({IP_RE})",
        rf"для\s+узла\s+с\s+ip[- ]?адресом\s*({IP_RE})",
        rf"уз[её]л\s+с\s+ip[- ]?адресом\s*({IP_RE})",
        rf"для\s+узла\s*({IP_RE})",
        rf"узла\s*({IP_RE})",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return match.group(1)

    # If a mask exists, take the first IP that is not the mask and not an example IP.
    mask = find_mask(text)
    for ip in find_all_ips(text):
        if ip == mask:
            continue
        if ip in {"231.32.255.131", "111.22.3.44", "192.168.128.0"}:
            continue
        return ip
    return None


def find_network_address_from_statement(text: str) -> str | None:
    text = normalize_text(text)
    patterns = [
        rf"адрес\s+сети\s*(?:равен|:)?\s*({IP_RE})",
        rf"адресом\s+сети\s*(?:равен|:)?\s*({IP_RE})",
    ]
    for pattern in patterns:
        for match in re.finditer(pattern, text, flags=re.I):
            ip = match.group(1)
            # Ignore common educational example addresses.
            if ip not in {"231.32.240.0", "192.168.128.0"}:
                return ip
    return None


def find_two_host_ips(text: str) -> tuple[str, str] | None:
    text = normalize_text(text)
    patterns = [
        rf"узлы\s+с\s+ip[- ]?адресами\s*({IP_RE})\s+и\s+({IP_RE})",
        rf"ip[- ]?адресами\s*({IP_RE})\s+и\s+({IP_RE})",
    ]
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.I)
        if match:
            return match.group(1), match.group(2)
    return None


def find_byte_number(text: str) -> int | None:
    text = lower_normalized(text)
    word_to_number = {
        "перв": 1,
        "втор": 2,
        "трет": 3,
        "четверт": 4,
        "1": 1,
        "2": 2,
        "3": 3,
        "4": 4,
    }
    match = re.search(r"(перв\w*|втор\w*|трет\w*|четверт\w*|[1-4])\s+(?:слева\s+)?байт", text)
    if not match:
        match = re.search(r"байт\w*\s*(?:номер\s*)?([1-4])", text)
    if match:
        token = match.group(1)
        for word, number in word_to_number.items():
            if token.startswith(word):
                return number
    return None


# ------------------------- letter table parsing -------------------------


def parse_letter_table(text: str) -> dict[int, str]:
    """
    Find a table like:
        A B C D E F G H
        0 81 113 128 130 145 199 225
    Return {number: letter}. Only the part before the word 'Пример' is used.
    """
    text = normalize_text(text)
    before_example = re.split(r"\bПример\b", text, flags=re.I)[0]
    lines = [line.strip() for line in before_example.splitlines() if line.strip()]

    for i in range(len(lines) - 1):
        letters = re.findall(r"\b[A-HА-Н]\b", lines[i])
        numbers = re.findall(r"\b\d{1,3}\b", lines[i + 1])
        if len(letters) >= 4 and len(letters) == len(numbers):
            return {int(number): letters[j] for j, number in enumerate(numbers)}

    # If the whole table was copied into one line.
    match = re.search(r"\b(A\s+B\s+C\s+D(?:\s+E\s+F\s+G\s+H)?)\b(.{1,120})", before_example, flags=re.I | re.S)
    if match:
        letters = re.findall(r"\b[A-H]\b", match.group(1), flags=re.I)
        numbers = re.findall(r"\b\d{1,3}\b", match.group(2))[:len(letters)]
        if len(letters) == len(numbers):
            return {int(number): letters[j].upper() for j, number in enumerate(numbers)}
    return {}


def format_ip_answer(ip_as_int: int, text: str) -> str:
    ip = int_to_ip(ip_as_int)
    lowered = lower_normalized(text)
    if "без разделител" in lowered or "без точек" in lowered:
        return ip.replace(".", "")
    return ip


# ------------------------- bit-count conditions -------------------------


def make_ones_condition(text: str):
    """
    Return a function f(total_ones) -> bool for a 32-bit IP address.

    Important: the task text is Russian, so Russian words are intentionally kept
    inside regex patterns. Everything related to code names stays in English.

    Supported conditions:
    - equal number of ones and zeroes;
    - even/odd number of ones;
    - even/odd number of zeroes;
    - divisibility/non-divisibility of the number of ones;
    - exactly N ones/zeroes;
    - comparisons: at least, at most, more than, fewer than N ones/zeroes.
    """
    text = lower_normalized(text)

    def has_near(word_pattern: str, object_pattern: str, distance: int = 90) -> bool:
        """Check that two Russian phrases are close to each other in either order."""
        pattern = (
            rf"(?:{word_pattern})[^.?!\n]{{0,{distance}}}(?:{object_pattern})"
            rf"|(?:{object_pattern})[^.?!\n]{{0,{distance}}}(?:{word_pattern})"
        )
        return re.search(pattern, text) is not None

    ones_word = r"единиц\w*"
    zeroes_word = r"нул\w*"
    odd_word = r"\b(?:не\s*чет\w*|нечет\w*)"
    even_word = r"\bчет\w*"

    if (
        "единиц" in text
        and "нул" in text
        and any(word in text for word in ["одинаков", "равн", "столько же"])
    ):
        return lambda ones: ones == 16

    # In a 32-bit address the parity of the number of zeroes is the same
    # as the parity of the number of ones, because 32 is even.
    if has_near(odd_word, ones_word) or has_near(odd_word, zeroes_word):
        return lambda ones: ones % 2 == 1

    if has_near(even_word, ones_word) or has_near(even_word, zeroes_word):
        return lambda ones: ones % 2 == 0

    match = re.search(r"(?:количество|сумма)\s+единиц[^.?!\n]*?не\s+крат\w*\s+(\d+)", text)
    if match:
        divisor = int(match.group(1))
        return lambda ones, divisor=divisor: ones % divisor != 0

    match = re.search(r"(?:количество|сумма)\s+единиц[^.?!\n]*?крат\w*\s+(\d+)", text)
    if match:
        divisor = int(match.group(1))
        return lambda ones, divisor=divisor: ones % divisor == 0

    match = re.search(r"(?:содержит|содержат|содержится)[^.?!\n]*?ровно\s+(\d+)\s+единиц", text)
    if match:
        required = int(match.group(1))
        return lambda ones, required=required: ones == required

    match = re.search(r"(?:содержит|содержат|содержится)[^.?!\n]*?ровно\s+(\d+)\s+нул", text)
    if match:
        required = int(match.group(1))
        return lambda ones, required=required: 32 - ones == required

    comparison_patterns = [
        (r"не\s+менее\s+(\d+)\s+единиц", lambda ones, limit: ones >= limit),
        (r"не\s+более\s+(\d+)\s+единиц", lambda ones, limit: ones <= limit),
        (r"более\s+(\d+)\s+единиц", lambda ones, limit: ones > limit),
        (r"менее\s+(\d+)\s+единиц", lambda ones, limit: ones < limit),
        (r"не\s+менее\s+(\d+)\s+нул", lambda ones, limit: 32 - ones >= limit),
        (r"не\s+более\s+(\d+)\s+нул", lambda ones, limit: 32 - ones <= limit),
        (r"более\s+(\d+)\s+нул", lambda ones, limit: 32 - ones > limit),
        (r"менее\s+(\d+)\s+нул", lambda ones, limit: 32 - ones < limit),
    ]

    for pattern, make_condition in comparison_patterns:
        match = re.search(pattern, text)
        if match:
            limit = int(match.group(1))

            def condition(ones: int, limit: int = limit, make_condition=make_condition) -> bool:
                return make_condition(ones, limit)

            return condition

    return None

def count_by_bits_combinatorially(
    ip: str,
    mask: str,
    condition,
    exclude_service_addresses: bool = False,
) -> int:
    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    fixed_ones = (network >> (32 - prefix)).bit_count() if prefix else 0
    host_bits = 32 - prefix

    answer = 0
    for host_ones in range(host_bits + 1):
        if condition(fixed_ones + host_ones):
            answer += comb(host_bits, host_ones)

    if exclude_service_addresses and host_bits >= 1:
        if condition(fixed_ones):
            answer -= 1  # network address
        if condition(fixed_ones + host_bits):
            answer -= 1  # broadcast address
    return answer


def should_exclude_service_addresses(text: str) -> bool:
    text = lower_normalized(text)
    if "учитывать" in text:
        return False
    if "не могут быть использованы" in text or "не могут использоваться" in text:
        return any(word in text for word in ["устройств", "устройства", "компьютер", "компьютера", "узлов"])
    return any(word in text for word in ["адресов компьютеров", "адреса компьютеров", "адреса устройств", "адресов устройств"])


def count_addresses_by_mask(mask: str, text: str) -> int:
    host_bits = 32 - prefix_from_mask(mask)
    answer = 2 ** host_bits
    lowered = lower_normalized(text)
    if (
        "компьют" in lowered
        or "устройств" in lowered
        or "не используют" in lowered
        or "не используются" in lowered
    ) and "учитывать" not in lowered:
        answer -= 2
    return answer


# ------------------------- concrete task solvers -------------------------


def solve_network_address(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if "определите адрес сети" not in lowered and "адрес сети" not in lowered:
        return None

    ip = find_host_ip(text)
    mask = find_mask(text)
    if not ip or not mask:
        return None

    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    octets = get_octets(network)
    table = parse_letter_table(text)

    if table:
        try:
            answer = "".join(table[octet] for octet in octets)
        except KeyError:
            answer = format_ip_answer(network, text)
        return Result(answer, "network address by IP and mask", f"{ip} AND {mask} = {int_to_ip(network)}")

    return Result(
        format_ip_answer(network, text),
        "network address by IP and mask",
        f"{ip} AND {mask} = {int_to_ip(network)}",
    )


def solve_host_number(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if not any(phrase in lowered for phrase in ["номер компьютера", "порядковый номер", "номер узла"]):
        return None

    ip = find_host_ip(text)
    mask = find_mask(text)
    if not ip or not mask:
        return None

    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    answer = ip_to_int(ip) - network
    return Result(
        answer,
        "host number in network",
        f"Network address: {int_to_ip(network)}. Host number = int({ip}) - int({int_to_ip(network)}) = {answer}.",
    )


def solve_count_by_mask(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if "сколько" not in lowered:
        return None
    if not any(
        phrase in lowered
        for phrase in ["различных адрес", "адресов компьют", "адресов устройств", "адресов в этой сети"]
    ):
        return None

    # Tasks with an extra condition on ones are handled by another solver.
    if make_ones_condition(text) is not None and find_host_ip(text) and find_mask(text):
        return None

    mask = find_mask(text)
    if not mask:
        return None

    answer = count_addresses_by_mask(mask, text)
    host_bits = 32 - prefix_from_mask(mask)
    return Result(
        answer,
        "address count by mask",
        f"Mask {mask} has {host_bits} host bits. Total is 2^{host_bits}; service addresses are subtracted when needed.",
    )


def valid_prefixes_for_ip_and_network(ip: str, network_ip: str) -> list[int]:
    prefixes: list[int] = []
    for prefix in range(33):
        if network_to_int(ip, prefix) == ip_to_int(network_ip):
            prefixes.append(prefix)
    return prefixes


def solve_mask_by_ip_and_network(text: str) -> Result | None:
    lowered = lower_normalized(text)
    ip = find_host_ip(text)
    network_ip = find_network_address_from_statement(text)
    if not ip or not network_ip:
        return None

    valid_prefixes = valid_prefixes_for_ip_and_network(ip, network_ip)
    if not valid_prefixes:
        return None

    byte_number = find_byte_number(text)
    if byte_number:
        values = [mask_octets(prefix)[byte_number - 1] for prefix in valid_prefixes]
        if "наимень" in lowered:
            answer = min(values)
            task_type = f"minimum mask byte {byte_number}"
        else:
            answer = max(values)
            task_type = f"maximum mask byte {byte_number}"
        possible_masks = [int_to_ip(mask_from_prefix(prefix)) for prefix in valid_prefixes]
        return Result(answer, task_type, f"Valid mask lengths: {valid_prefixes}. Possible masks: {possible_masks}.")

    if "количество" in lowered and "единиц" in lowered:
        answer = min(valid_prefixes) if "наимень" in lowered else max(valid_prefixes)
        return Result(answer, "number of ones in mask", f"Valid mask lengths: {valid_prefixes}.")

    if "количество" in lowered and "адрес" in lowered:
        def count_for(prefix: int) -> int:
            total = 2 ** (32 - prefix)
            if should_exclude_service_addresses(text):
                total -= 2
            return total

        values = [count_for(prefix) for prefix in valid_prefixes]
        answer = max(values) if "наибольш" in lowered else min(values)
        return Result(answer, "address count while choosing mask", f"Valid mask lengths: {valid_prefixes}.")

    return None


def valid_prefixes_for_two_ips(ip1: str, ip2: str) -> list[int]:
    return [prefix for prefix in range(33) if network_to_int(ip1, prefix) == network_to_int(ip2, prefix)]


def solve_count_ips_with_condition_by_two_ips(text: str) -> Result | None:
    pair = find_two_host_ips(text)
    if not pair:
        return None

    lowered = lower_normalized(text)
    if not ("количество" in lowered and "ip" in lowered and "адрес" in lowered):
        return None

    condition = make_ones_condition(text)
    if condition is None:
        return None

    ip1, ip2 = pair
    valid_prefixes = valid_prefixes_for_two_ips(ip1, ip2)
    if not valid_prefixes:
        return None

    variants: list[tuple[int, int]] = []
    for prefix in valid_prefixes:
        mask = int_to_ip(mask_from_prefix(prefix))
        count = count_by_bits_combinatorially(ip1, mask, condition, should_exclude_service_addresses(text))
        variants.append((prefix, count))

    counts = [count for _, count in variants]
    if "наибольш" in lowered or "максим" in lowered:
        answer = max(counts)
    else:
        answer = min(counts)

    return Result(
        answer,
        "counting IP addresses with a bit condition by two IP addresses",
        f"Valid mask lengths and counts: {variants}.",
    )


def solve_mask_by_two_ips(text: str) -> Result | None:
    pair = find_two_host_ips(text)
    if not pair:
        return None

    lowered = lower_normalized(text)
    ip1, ip2 = pair
    valid_prefixes = valid_prefixes_for_two_ips(ip1, ip2)
    if not valid_prefixes:
        return None

    byte_number = find_byte_number(text)
    if byte_number:
        values = [mask_octets(prefix)[byte_number - 1] for prefix in valid_prefixes]
        answer = min(values) if "наимень" in lowered else max(values)
        return Result(answer, "mask byte by two IP addresses", f"Valid mask lengths: {valid_prefixes}.")

    if "единиц" in lowered or "маск" in lowered:
        answer = min(valid_prefixes) if "наимень" in lowered else max(valid_prefixes)
        return Result(answer, "number of ones in mask by two IP addresses", f"Both IPs are in one network for mask lengths: {valid_prefixes}.")

    return None


def solve_mask_by_count_of_ips_with_ones(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if not ("принадлежит сети" in lowered and "сколько единиц" in lowered and "маск" in lowered):
        return None

    ip = find_host_ip(text)
    if not ip:
        return None

    count_match = re.search(r"в\s+которой\s+(\d+)\s+ip[- ]?адрес", lowered)
    ones_match = re.search(r"содерж\w*\s+ровно\s+(\d+)\s+единиц", lowered)
    if not count_match or not ones_match:
        return None

    required_count = int(count_match.group(1))
    required_ones = int(ones_match.group(1))

    good_prefixes: list[int] = []
    for prefix in range(33):
        network = network_to_int(ip, prefix)
        fixed_ones = (network >> (32 - prefix)).bit_count() if prefix else 0
        host_bits = 32 - prefix
        count = 0
        for host_ones in range(host_bits + 1):
            if fixed_ones + host_ones == required_ones:
                count += comb(host_bits, host_ones)
        if count == required_count:
            good_prefixes.append(prefix)

    if good_prefixes:
        answer = good_prefixes[0] if len(good_prefixes) == 1 else good_prefixes
        return Result(answer, "mask by number of IP addresses with exactly K ones", f"Valid mask lengths: {good_prefixes}.")

    return None


def solve_count_ips_with_condition(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if "сколько" not in lowered or "ip" not in lowered:
        return None

    condition = make_ones_condition(text)
    if condition is None:
        return None

    ip = find_host_ip(text)
    mask = find_mask(text)
    if not ip or not mask:
        return None

    answer = count_by_bits_combinatorially(
        ip,
        mask,
        condition,
        should_exclude_service_addresses(text),
    )
    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    return Result(
        answer,
        "counting IP addresses with a bit condition",
        f"Network: {int_to_ip(network)}/{prefix}. Count was computed using fixed and host-part ones.",
    )


def solve_max_octet_sum(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if not ("сумм" in lowered and "октет" in lowered and ("наибольш" in lowered or "максим" in lowered)):
        return None

    ip = find_host_ip(text)
    mask = find_mask(text)
    condition = make_ones_condition(text)
    if not ip or not mask or condition is None:
        return None

    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    host_bits = 32 - prefix
    fixed_ones = (network >> host_bits).bit_count() if prefix else 0

    # Frequent type: equal number of ones and zeroes means exactly 16 ones in a 32-bit IP.
    if condition(16) and not condition(15) and not condition(17):
        needed_host_ones = 16 - fixed_ones
        if not (0 <= needed_host_ones <= host_bits):
            return None

        host_positions = list(range(host_bits))  # 0 is the least significant bit of the full IP.

        def bit_weight(position_from_right: int) -> int:
            return 1 << (position_from_right % 8)

        chosen_positions = set(sorted(host_positions, key=bit_weight, reverse=True)[:needed_host_ones])
        host_part = sum(1 << position for position in chosen_positions)
        candidate = network | host_part

        if should_exclude_service_addresses(text) and (candidate == network or candidate == broadcast_to_int(ip, prefix)):
            candidate = None

        if candidate is not None:
            answer = sum(get_octets(candidate))
            return Result(answer, "maximum octet sum", f"Best IP: {int_to_ip(candidate)}, octet sum = {answer}.")

    # Fallback brute force for small/medium networks.
    limit = 2 ** host_bits
    if limit > 3_000_000:
        raise RuntimeError(
            "Network is too large for full brute force with this non-standard condition. "
            "Add a rule to make_ones_condition or narrow the task type."
        )

    start = 1 if should_exclude_service_addresses(text) and host_bits else 0
    finish = limit - 1 if should_exclude_service_addresses(text) and host_bits else limit
    best_sum: int | None = None
    best_ip: int | None = None

    for host in range(start, finish):
        current_ip = network | host
        if condition(current_ip.bit_count()):
            octet_sum = sum(get_octets(current_ip))
            if best_sum is None or octet_sum > best_sum:
                best_sum = octet_sum
                best_ip = current_ip

    if best_sum is not None and best_ip is not None:
        return Result(best_sum, "maximum octet sum", f"Best IP: {int_to_ip(best_ip)}, octet sum = {best_sum}.")

    return None


def solve_extreme_device_ip(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if not ("ip-адрес" in lowered or "ip адрес" in lowered):
        return None
    if not any(word in lowered for word in ["наибольший", "наименьший", "максимальный", "минимальный"]):
        return None
    if not any(
        word in lowered
        for word in ["назначен компьютеру", "назначен узлу", "назначен устройству", "адрес устройства", "адрес компьютера"]
    ):
        return None

    ip = find_host_ip(text)
    mask = find_mask(text)
    if not ip or not mask:
        return None

    prefix = prefix_from_mask(mask)
    network = network_to_int(ip, prefix)
    broadcast = broadcast_to_int(ip, prefix)

    if "наимень" in lowered or "миним" in lowered:
        answer_ip = network + 1 if broadcast > network else network
    else:
        answer_ip = broadcast - 1 if broadcast > network else broadcast

    return Result(
        format_ip_answer(answer_ip, text),
        "extreme device address in network",
        f"Network: {int_to_ip(network)}/{prefix}, broadcast: {int_to_ip(broadcast)}.",
    )


def solve_network_host_ones_equality(text: str) -> Result | None:
    lowered = lower_normalized(text)
    if not ("адреса сети" in lowered and "номера узла" in lowered and "тем же свойством" in lowered):
        return None

    ip = find_host_ip(text)
    if not ip:
        return None

    ip_as_int = ip_to_int(ip)
    answers: list[tuple[int, int]] = []

    for prefix in range(33):
        mask = mask_from_prefix(prefix)
        network_part = ip_as_int & mask
        host_part = ip_as_int & ((1 << (32 - prefix)) - 1)
        network_ones = network_part.bit_count()
        host_ones = host_part.bit_count()

        if network_ones == host_ones:
            host_bits = 32 - prefix
            count = comb(host_bits, network_ones) if 0 <= network_ones <= host_bits else 0
            answers.append((prefix, count))

    if not answers:
        return None

    answer = max(count for _, count in answers) if "наибольш" in lowered else answers[0][1]
    return Result(
        answer,
        "number of hosts where network-address ones equal host-number ones",
        f"Valid mask lengths and counts: {answers}.",
    )


# ------------------------- main entry point -------------------------


def solve_ege13(task_text: str, detailed: bool = True) -> Result:
    """
    Automatically detect task 13 type and return the answer.
    Even with detailed=False, the returned object still has .answer, .task_type, .explanation.
    """
    text = normalize_text(task_text)

    solvers = [
        solve_network_host_ones_equality,
        solve_max_octet_sum,
        solve_extreme_device_ip,
        solve_mask_by_count_of_ips_with_ones,
        solve_count_ips_with_condition_by_two_ips,
        solve_count_ips_with_condition,
        solve_host_number,
        solve_mask_by_ip_and_network,
        solve_mask_by_two_ips,
        solve_network_address,
        solve_count_by_mask,
    ]

    errors: list[str] = []
    for solver in solvers:
        try:
            result = solver(text)
            if result is not None:
                if not detailed:
                    result.explanation = ""
                return result
        except Exception as error:
            errors.append(f"{solver.__name__}: {error}")

    debug = "\n".join(errors[-3:])
    raise ValueError(
        "Could not recognize the task type. Check that the text contains an IP/mask and a question.\n"
        "You can add a new pattern to the solver list.\n"
        + debug
    )


# Short English alias.
solve = solve_ege13


if __name__ == "__main__":
    print("Import solve_ege13 from this file and pass a task statement to it.")
