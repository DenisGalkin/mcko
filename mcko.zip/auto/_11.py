from __future__ import annotations

import itertools
import re
from dataclasses import dataclass
from typing import Any, Callable

DIGITS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ"
VAR_CHARS = set("xyzpabcdekmnqrtuv")  # маленькие буквы считаем неизвестными


class TaskParserError(Exception):
    pass


@dataclass
class SolveResult:
    answer: Any
    expression: str
    mode: str
    solutions: list[dict[str, Any]]

    def __str__(self) -> str:
        return str(self.answer)


# -------------------------
# Нормализация текста
# -------------------------

def normalize_text(text: str) -> str:
    """Приводим текст к виду, который проще парсить."""
    repl = {
        "−": "-",
        "–": "-",
        "—": "-",
        "·": "*",
        "×": "*",
        "Х": "x",  # русская Х
        "х": "x",  # русская х
        "⁰": "0", "¹": "1", "²": "2", "³": "3", "⁴": "4",
        "⁵": "5", "⁶": "6", "⁷": "7", "⁸": "8", "⁹": "9",
    }
    for a, b in repl.items():
        text = text.replace(a, b)
    text = text.replace("^", "**")
    return text


# -------------------------
# Перевод систем счисления
# -------------------------

def digit_value(ch: str, variables: dict[str, int] | None = None) -> int:
    """Возвращает числовое значение цифры."""
    variables = variables or {}
    if ch in variables:
        return int(variables[ch])
    ch = ch.upper()
    if ch not in DIGITS:
        raise ValueError(f"Неизвестная цифра: {ch}")
    return DIGITS.index(ch)


def from_base(num: str, base: int, variables: dict[str, int] | None = None) -> int:
    """Переводит число num из системы base в десятичную."""
    variables = variables or {}
    base = int(base)

    if not (2 <= base <= len(DIGITS)):
        raise ValueError(f"Основание вне диапазона 2..36: {base}")

    num = str(num).strip()
    if not num:
        raise ValueError("Пустое число")

    # Запрещаем ведущий ноль у обычной позиционной записи.
    if len(num) > 1:
        first = digit_value(num[0], variables)
        if first == 0:
            raise ValueError(f"Ведущий ноль в записи числа {num}_{base}")

    value = 0
    for ch in num:
        d = digit_value(ch, variables)
        if d >= base:
            raise ValueError(f"Цифра {ch}={d} не подходит для основания {base}")
        value = value * base + d
    return value


def to_base(number: int, base: int) -> str:
    """Переводит десятичное целое число в систему base."""
    number = int(number)
    base = int(base)
    if not (2 <= base <= len(DIGITS)):
        raise ValueError(f"Основание вне диапазона 2..36: {base}")
    if number == 0:
        return "0"
    sign = ""
    if number < 0:
        sign = "-"
        number = -number
    result = ""
    while number:
        number, r = divmod(number, base)
        result = DIGITS[r] + result
    return sign + result


def digits_in_base(number: int, base: int) -> list[int]:
    """Возвращает список цифр записи числа в системе base."""
    s = to_base(abs(int(number)), int(base))
    return [DIGITS.index(ch) for ch in s]


# -------------------------
# Работа с выражениями
# -------------------------

BASE_LITERAL_RE = re.compile(r"(?<![A-Za-zА-Яа-я0-9])([0-9A-Za-z]+)_([0-9A-Za-z]+)(?![A-Za-zА-Яа-я0-9])")


def base_literal_to_python(match: re.Match[str]) -> str:
    """Заменяет 123_5 на B('123', 5), а 52x31_p на B('52x31', p)."""
    num, base = match.group(1), match.group(2)
    if base.isdigit():
        return f"B('{num}', {int(base)})"
    return f"B('{num}', {base})"


def prepare_expr(expr: str) -> str:
    """Готовит выражение к eval."""
    expr = normalize_text(expr)
    expr = expr.replace(" ", "")
    expr = BASE_LITERAL_RE.sub(base_literal_to_python, expr)
    return expr


def safe_eval(expr: str, variables: dict[str, int] | None = None) -> int:
    """Вычисляет выражение с числами вида 123_5."""
    variables = variables or {}

    def B(num: str, base: int) -> int:
        return from_base(num, int(base), variables)

    env = {"B": B, "abs": abs}
    env.update(variables)
    prepared = prepare_expr(expr)
    try:
        return int(eval(prepared, {"__builtins__": {}}, env))
    except Exception as e:
        raise ValueError(f"Не удалось вычислить выражение: {expr}\nПосле обработки: {prepared}\nОшибка: {e}")


def split_equation(expr: str) -> tuple[str, str] | None:
    """Если в выражении есть равенство, возвращает левую и правую части."""
    if "==" in expr:
        left, right = expr.split("==", 1)
        return left, right
    if "=" in expr:
        left, right = expr.split("=", 1)
        return left, right
    return None


# -------------------------
# Извлечение выражения из текста
# -------------------------

def extract_expression(text: str) -> str:
    """Пытается найти главное математическое выражение в тексте задачи."""
    text = normalize_text(text)

    # Если пользователь явно пометил выражение.
    explicit = re.search(r"(?:expr|expression|выражение)\s*[:=]\s*(.+)", text, re.IGNORECASE)
    if explicit:
        line = explicit.group(1).strip()
        if line:
            return clean_expression(line)

    candidates: list[str] = []

    # 1) Сначала смотрим отдельные строки. В ЕГЭ выражение часто стоит отдельной строкой.
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        candidates.extend(extract_math_fragments(line))

    # 2) Если строк мало, ищем по всему тексту.
    candidates.extend(extract_math_fragments(text))

    scored: list[tuple[int, str]] = []
    for c in candidates:
        c = clean_expression(c)
        if not looks_like_expression(c):
            continue
        score = expression_score(c)
        scored.append((score, c))

    if not scored:
        raise TaskParserError(
            "Не нашёл выражение в тексте. Подсказка: поставь выражение на отдельную строку "
            "или напиши, например: expression: 123x5_15 + 1x233_15"
        )

    scored.sort(reverse=True, key=lambda x: x[0])
    return scored[0][1]


def extract_math_fragments(line: str) -> list[str]:
    """Достаёт куски, похожие на математические выражения."""
    # Разрешаем латинские буквы, так как A-F могут быть цифрами, а x/p могут быть неизвестными.
    fragments = re.findall(r"[0-9A-Za-z_()+\-*/^=\s]+", line)
    return [f.strip() for f in fragments if f.strip()]


def clean_expression(expr: str) -> str:
    """Убирает лишнее по краям выражения."""
    expr = normalize_text(expr).strip()
    expr = expr.strip(" .,:;№")

    # Часто после выражения в той же строке идёт текст. Обрезаем после первой большой паузы из слов не можем,
    # поэтому просто оставляем допустимые символы до первого явно лишнего символа уже на этапе fragment.
    expr = re.sub(r"\s+", " ", expr)
    return expr


def looks_like_expression(expr: str) -> bool:
    """Проверяет, похоже ли это на выражение, а не на случайное число из текста."""
    if not re.search(r"\d", expr):
        return False
    has_base_literal = bool(BASE_LITERAL_RE.search(expr))
    has_operator = bool(re.search(r"[+\-*/=]", expr)) or "**" in expr
    has_power = "**" in expr or "^" in expr
    # Одно число вида 10101_2 тоже считаем выражением.
    return has_base_literal or has_operator or has_power


def expression_score(expr: str) -> int:
    """Чем больше балл, тем вероятнее, что это главное выражение."""
    score = len(expr)
    score += 80 * len(BASE_LITERAL_RE.findall(expr))
    score += 20 * len(re.findall(r"[+\-*/=]", expr))
    score += 30 * expr.count("**")
    # Штраф за слишком короткие куски типа "14".
    if len(expr) < 4:
        score -= 100
    return score


# -------------------------
# Определение неизвестных
# -------------------------

def find_variables(expr: str) -> tuple[set[str], set[str]]:
    """Возвращает (неизвестные_цифры, неизвестные_основания)."""
    digit_vars: set[str] = set()
    base_vars: set[str] = set()

    for num, base in BASE_LITERAL_RE.findall(expr):
        for ch in num:
            if ch.islower() and ch in VAR_CHARS:
                digit_vars.add(ch)
        if not base.isdigit():
            for ch in base:
                if ch.islower() and ch in VAR_CHARS:
                    base_vars.add(ch)

    # Дополнительно ловим переменные в обычном выражении, но не трогаем B из внутренней замены.
    for ch in re.findall(r"\b([xyzpabcdekmnqrtuv])\b", expr):
        digit_vars.add(ch)

    return digit_vars, base_vars


def max_known_digit(num: str, variables: dict[str, int] | None = None) -> int:
    variables = variables or {}
    values = []
    for ch in num:
        if ch in variables:
            values.append(int(variables[ch]))
        elif ch.islower() and ch in VAR_CHARS:
            continue
        else:
            values.append(digit_value(ch))
    return max(values) if values else 0


def build_ranges(expr: str, digit_vars: set[str], base_vars: set[str]) -> dict[str, range]:
    """Строит диапазоны перебора для неизвестных."""
    ranges: dict[str, range] = {}

    # Для неизвестных цифр берём 0..минимальное_известное_основание-1.
    for v in digit_vars:
        limit = 36
        for num, base in BASE_LITERAL_RE.findall(expr):
            if v in num and base.isdigit():
                limit = min(limit, int(base))
        ranges[v] = range(0, limit)

    # Для неизвестных оснований перебираем 2..36.
    for v in base_vars:
        ranges[v] = range(2, 37)

    return ranges


def valid_assignment(expr: str, variables: dict[str, int]) -> bool:
    """Проверяет, подходят ли значения неизвестных для всех чисел."""
    try:
        for num, base_raw in BASE_LITERAL_RE.findall(expr):
            if base_raw.isdigit():
                base = int(base_raw)
            else:
                if base_raw not in variables:
                    return False
                base = int(variables[base_raw])
            from_base(num, base, variables)
        return True
    except Exception:
        return False


# -------------------------
# Извлечение условий из русского текста
# -------------------------

def lower_ru(text: str) -> str:
    return normalize_text(text).lower().replace("ё", "е")


def infer_target_base(text: str) -> int | None:
    """Ищет основание системы, в которую надо перевести результат."""
    t = lower_ru(text)
    patterns = [
        r"с основани(?:ем|я|и)\s*(\d+)",
        r"в\s+(\d+)\s*-?\s*(?:ричной|ичной|ой)\s+систем",
        r"в\s+системе\s+счисления\s+с\s+основани(?:ем|я|и)\s*(\d+)",
    ]
    nums: list[int] = []
    for p in patterns:
        nums.extend(int(x) for x in re.findall(p, t))
    if not nums:
        return None
    # Обычно последнее упоминание основания после слов "записали в системе..." — нужное для ответа.
    return nums[-1]


def infer_divisor(text: str) -> int | None:
    """Ищет делитель из фраз кратно N / делится на N."""
    t = lower_ru(text)
    patterns = [
        r"кратн\w*\s+(\d+)",
        r"делит\w*\s+на\s+(\d+)",
        r"делени[яеи]\s+на\s+(\d+)",
    ]
    for p in patterns:
        m = re.search(p, t)
        if m:
            return int(m.group(1))
    return None


def infer_equal_number(text: str) -> int | None:
    """Ищет условие вида значение выражения равно N."""
    t = lower_ru(text)
    m = re.search(r"(?:равно|=)\s*(-?\d+)", t)
    if m:
        return int(m.group(1))
    return None


def infer_choose_mode(text: str) -> str:
    """Определяет, какое решение брать: min, max или first."""
    t = lower_ru(text)
    if any(w in t for w in ["наибольш", "максимальн"]):
        return "max"
    if any(w in t for w in ["наименьш", "минимальн"]):
        return "min"
    return "first"


def infer_answer_kind(text: str, variables: list[str]) -> tuple[str, Any]:
    """Понимает, что нужно вывести в ответ."""
    t = lower_ru(text)

    # Частотные формулировки для задач с неизвестной цифрой.
    if "частн" in t:
        return "quotient", None

    for v in variables:
        if re.search(rf"значени[ея]\s+{v}\b", t) or re.search(rf"переменн\w*\s+{v}\b", t):
            return "variable", v

    if "основан" in t and variables:
        # Если среди переменных есть p/y и они стоят в основании, часто ответ — это основание.
        for v in variables:
            if v in "pynq":
                return "variable", v

    # Формулировки для задач на анализ записи числа.
    count_info = infer_count_condition(text)
    if count_info is not None:
        return "digit_stat", count_info

    if "сумм" in t and "цифр" in t:
        return "digit_stat", ("sum", None)

    if "количество цифр" in t or "число цифр" in t or "длина" in t:
        return "digit_stat", ("len", None)

    if "различн" in t and "цифр" in t:
        return "digit_stat", ("different", None)

    if "максимальн" in t and "цифр" in t:
        return "digit_stat", ("max_digit", None)

    if "минимальн" in t and "цифр" in t:
        return "digit_stat", ("min_digit", None)

    if "запиш" in t and "систем" in t:
        return "representation", None

    # По умолчанию выводим значение выражения.
    return "value", None


def infer_count_condition(text: str) -> tuple[str, Any] | None:
    """Понимает условия вида 'сколько нулей', 'сколько цифр больше 9'."""
    t = lower_ru(text)

    word_digits = {
        "нул": 0,
        "единиц": 1,
        "единиц": 1,
        "дво": 2,
        "тро": 3,
        "четвер": 4,
        "пят": 5,
        "шестер": 6,
        "семер": 7,
        "восьмер": 8,
        "девят": 9,
    }

    # Сначала специальные сравнения, порядок важен: "не превышает" раньше "превышает".
    m = re.search(r"цифр\w*(?:\s+с\s+числовым\s+значением)?\s*,?\s*не\s+превыша\w*\s+(\d+)", t)
    if m:
        return "count_cmp", ("<=", int(m.group(1)))

    m = re.search(r"цифр\w*(?:\s+с\s+числовым\s+значением)?\s*,?\s*превыша\w*\s+(\d+)", t)
    if m:
        return "count_cmp", (">", int(m.group(1)))

    m = re.search(r"цифр\w*(?:\s+с\s+числовым\s+значением)?\s*(?:больше|боле[еe])\s+(\d+)", t)
    if m:
        return "count_cmp", (">", int(m.group(1)))

    m = re.search(r"цифр\w*(?:\s+с\s+числовым\s+значением)?\s*(?:меньше|мене[еe])\s+(\d+)", t)
    if m:
        return "count_cmp", ("<", int(m.group(1)))

    # Сколько цифр 0 / цифр 2 / цифра A.
    m = re.search(r"сколько\s+цифр\w*\s+([0-9A-Z])\b", normalize_text(text), re.IGNORECASE)
    if m:
        ch = m.group(1).upper()
        if ch in DIGITS:
            return "count_digit", DIGITS.index(ch)

    # Сколько нулей, единиц, двоек...
    for part, value in word_digits.items():
        if "сколько" in t and part in t:
            return "count_digit", value
        if "количество" in t and part in t:
            return "count_digit", value

    return None


def apply_digit_stat(number: int, base: int, info: tuple[str, Any]) -> Any:
    """Считает статистику по записи числа в системе base."""
    digits = digits_in_base(number, base)
    kind, arg = info

    if kind == "count_digit":
        return digits.count(int(arg))

    if kind == "count_cmp":
        op, value = arg
        if op == ">":
            return sum(d > value for d in digits)
        if op == ">=":
            return sum(d >= value for d in digits)
        if op == "<":
            return sum(d < value for d in digits)
        if op == "<=":
            return sum(d <= value for d in digits)
        if op == "==":
            return sum(d == value for d in digits)
        raise ValueError(f"Неизвестное сравнение: {op}")

    if kind == "sum":
        return sum(digits)
    if kind == "len":
        return len(digits)
    if kind == "different":
        return len(set(digits))
    if kind == "max_digit":
        return max(digits)
    if kind == "min_digit":
        return min(digits)

    raise ValueError(f"Неизвестная статистика цифр: {kind}")


# -------------------------
# Решение
# -------------------------

def solve_task(text: str, *, debug: bool = False) -> Any:
    """
    Главная функция.
    На вход подаётся полный текст задачи.
    На выходе — ответ.
    """
    original_text = text
    text = normalize_text(text)
    expr = extract_expression(text)

    digit_vars, base_vars = find_variables(expr)
    all_vars = sorted(digit_vars | base_vars)

    equation = split_equation(expr)
    target_base = infer_target_base(original_text)
    divisor = infer_divisor(original_text)
    equal_number = infer_equal_number(original_text)
    choose_mode = infer_choose_mode(original_text)
    answer_kind, answer_arg = infer_answer_kind(original_text, all_vars)

    if not all_vars:
        # Обычная задача: вычислить выражение и проанализировать запись в нужной системе.
        if equation:
            left, right = equation
            value = int(safe_eval(left) == safe_eval(right))
        else:
            value = safe_eval(expr)

        if answer_kind == "digit_stat":
            if target_base is None:
                raise TaskParserError("Не понял, в какой системе счисления надо анализировать запись числа.")
            answer = apply_digit_stat(value, target_base, answer_arg)
        elif answer_kind == "representation":
            if target_base is None:
                raise TaskParserError("Не понял основание системы счисления для записи ответа.")
            answer = to_base(value, target_base)
        else:
            answer = value

        if debug:
            return SolveResult(answer, expr, "no_variables", [{"n": value}])
        return answer

    # Задача с неизвестными цифрами/основаниями.
    ranges = build_ranges(expr, digit_vars, base_vars)
    names = sorted(ranges)
    solutions: list[dict[str, Any]] = []

    for values in itertools.product(*(ranges[name] for name in names)):
        variables = dict(zip(names, values))
        if not valid_assignment(expr, variables):
            continue

        try:
            if equation:
                left, right = equation
                left_value = safe_eval(left, variables)
                right_value = safe_eval(right, variables)
                ok = left_value == right_value
                n = left_value
            else:
                n = safe_eval(expr, variables)
                ok = True
                if divisor is not None:
                    ok = ok and (n % divisor == 0)
                if equal_number is not None:
                    ok = ok and (n == equal_number)
        except Exception:
            continue

        if ok:
            row = dict(variables)
            row["n"] = n
            solutions.append(row)

    if not solutions:
        raise TaskParserError(
            "Решений не найдено. Проверь, что числа с основанием записаны через подчёркивание: 123_5, 154x3_12."
        )

    # Выбираем нужное решение.
    main_var = all_vars[0]
    if answer_kind == "variable" and answer_arg in all_vars:
        main_var = answer_arg
    elif digit_vars:
        main_var = sorted(digit_vars)[0]
    elif base_vars:
        main_var = sorted(base_vars)[0]

    if choose_mode == "max":
        chosen = max(solutions, key=lambda r: (r.get(main_var, -1), r["n"]))
    elif choose_mode == "min":
        chosen = min(solutions, key=lambda r: (r.get(main_var, 10**9), r["n"]))
    else:
        chosen = solutions[0]

    # Формируем ответ.
    if answer_kind == "quotient":
        if divisor is None:
            raise TaskParserError("В тексте есть слово 'частное', но я не нашёл делитель.")
        answer = chosen["n"] // divisor
    elif answer_kind == "variable":
        answer = chosen[answer_arg]
    elif answer_kind == "digit_stat":
        if target_base is None:
            raise TaskParserError("Не понял основание системы счисления для анализа цифр.")
        answer = apply_digit_stat(chosen["n"], target_base, answer_arg)
    elif answer_kind == "representation":
        if target_base is None:
            raise TaskParserError("Не понял основание системы счисления для записи ответа.")
        answer = to_base(chosen["n"], target_base)
    else:
        # По умолчанию в задачах с x чаще всего нужен x, но если есть частное — оно уже обработано выше.
        answer = chosen.get(main_var, chosen["n"])

    if debug:
        return SolveResult(answer, expr, f"variables:{choose_mode}", solutions)
    return answer


# -------------------------
# Быстрые ручные функции, если понадобится
# -------------------------

def value(expr: str) -> int:
    """Просто вычислить выражение, где могут быть числа вида 123_5."""
    return safe_eval(expr)


def representation(expr: str, base: int) -> str:
    """Вычислить выражение и перевести результат в систему base."""
    return to_base(safe_eval(expr), base)


def count_digit(expr: str, base: int, digit: int | str) -> int:
    """Посчитать цифру digit в записи значения выражения в системе base."""
    if isinstance(digit, str):
        digit = DIGITS.index(digit.upper())
    return digits_in_base(safe_eval(expr), base).count(int(digit))
