from itertools import product, permutations
from inspect import signature


def solve(F, T, VARS=None, DEFAULT_F=None):
    if VARS is None:
        VARS = ''.join(signature(F).parameters)

    n = len(VARS)
    T2 = []

    for r in T:
        r = list(r)

        # Если столбца F вообще нет
        if len(r) == n:
            r.append(DEFAULT_F)

        # Если столбец F есть, но там None
        elif len(r) == n + 1 and r[-1] is None:
            r[-1] = DEFAULT_F

        elif len(r) != n + 1:
            raise ValueError(f'В строке должно быть {n} или {n + 1} значений')

        T2.append(r)

    # неизвестные клетки только среди переменных
    U = [
        (i, j)
        for i, r in enumerate(T2)
        for j, v in enumerate(r[:n])
        if v is None
    ]

    ans = set()

    for b in product([0, 1], repeat=len(U)):
        A = [r[:] for r in T2]

        for (i, j), v in zip(U, b):
            A[i][j] = v

        # строки таблицы истинности должны быть разными
        if len(A) != len({tuple(r[:n]) for r in A}):
            continue

        for p in permutations(VARS):
            ok = True

            for r in A:
                values = dict(zip(p, r[:n]))
                f = int(F(**values))

                # если F неизвестно и DEFAULT_F тоже None — не проверяем
                if r[-1] is not None and f != r[-1]:
                    ok = False
                    break

            if ok:
                ans.add(''.join(p))

    return sorted(ans)


def F(x, y, z, w):
    return (x <= y) and (y <= w) or (z == (x or y))


T = [
    [1, None, None, 1, 0],
    [1, None, None, None, 0],
    [None, 1, None, 1, 0],
]

print(*solve(F, T, DEFAULT_F=0))
