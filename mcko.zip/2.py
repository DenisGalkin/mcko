def F(n, osn):
    if n == 0:
        return '0'
    digits = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz'
    res = ''
    n = abs(n)
    while n:
        n, r = divmod(n, osn)
        if osn <= len(digits):
            res = digits[r] + res
        else:
            res = f'[{r}]' + res
    return ('-' if n < 0 else '') + res


for n in range(1, 100000):
    r = F(n, 2)
    # из условия
    r2 = int(r, 2)
    # из условия
